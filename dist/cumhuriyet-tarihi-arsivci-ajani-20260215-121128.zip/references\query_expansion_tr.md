# Query Expansion (TR)

Query matrix uretirken modern terim + donemsel varyant + kisaltma birlikte kullan.

## Terim Varyantlari

| Modern terim | Varyantlar / eski kullanim |
|---|---|
| bakanlar kurulu | heyet-i vekile, icra vekilleri heyeti |
| cumhurbaskanligi | reisicumhurluk, riyaset-i cumhur |
| meclis tutanagi | zabit ceridesi, tutanak dergisi |
| resmi gazete | resmi ceride (erken donem baglami) |
| genelge | tamim |
| yasa/kanun | kanun layihasi, kanun teklifi |
| disisleri | hariciye |
| milli savunma | mudafaa-i milliye |

## Kisi Varyanti Kurali

1. Soyad oncesi donem icin ad + unvan + gorev kombinasyonlari dene.
2. Kisaltma ve yazim varyanti ekle (ornek: M. Kemal, Mustafa Kemal).
3. Latin/Ottoman transliterasyon farkina acik ol.

## Kurum Varyanti Kurali

1. Kurumun tarihsel ad degisimlerini listele.
2. Kisaltma ve tam acilim birlikte ara (ornek: TBMM + Turkiye Buyuk Millet Meclisi).
3. Bagli birim/komisyon adlarini da sorguya ekle.

## Tarih Penceresi Kurali

1. Kritik olay tarihinin en az `-7/+30` gun penceresini tara.
2. Mevzuat veya atama adimi varsa onceki ve sonraki sayilari kontrol et.
3. Tarih normalizasyonu kullan: `YYYY-MM-DD`, bilinmiyorsa `YYYY`.
